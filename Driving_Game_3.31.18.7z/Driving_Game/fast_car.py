# Car
car_w = 10
car_l = 20

accel = 1.8
turningradius = 1.1
drag = .15
