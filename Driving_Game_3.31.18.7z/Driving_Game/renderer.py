pygame.draw.rect(screen, FINISHLINE, finish)

# Draw the obstacle
for x in range(0, len(obst_x)):
    pygame.draw.rect(screen, OBSTACLES, [obst_x[x], obst_y[x], obst_w[x], obst_h[x]])


if joystick_yn < 2:
    laps_formatted_1p = str(laps_1p)
    laps_formatted_2p = str(laps_2p)
    laps_gui_1p = myfont.render('Laps:', 1, TEXT)
    laps_count_1p = myfont.render(str(laps_formatted_1p), 1, TEXT)
most_gui_1p = myfont.render('Most Laps:', 1, TEXT)
most_count_1p = myfont.render(str(maxlaps_1p), 1, TEXT)
time_gui_1p = myfont.render('This Run:', 1, TEXT)
time_val_1p = myfont.render(str(timer_1p), 1, TEXT)
fastest_gui_1p = myfont.render('Fastest:', 1, TEXT)
fastest_val_1p = myfont.render(str(fast_str_1p), 1, TEXT)
last_gui_1p = myfont.render('Last Lap:', 1, TEXT)
last_val_1p = myfont.render(str(last_str_1p), 1, TEXT)
speed_gui_1p = myfont.render('Speed:', 1, TEXT)
speed_val_1p = myfont.render(str(speed_1p), 1, TEXT)

if last_laptime_1p == 0:
    last_val_1p = myfont.render("--", 1, TEXT)
if last_str_1p == 0:
    last_val_1p = myfont.render("--", 1, TEXT)

if joystick_yn == 2:
    laps_formatted_1p = str(laps_1p)+ '/5'
    laps_formatted_2p = str(laps_2p)+ '/5'
    laps_gui_1p = myfont.render('Laps:', 1, TEXT)
    laps_count_1p = myfont.render(str(laps_formatted_1p), 1, TEXT)
    laps_gui_2p = myfont.render('Laps:', 1, TEXT)
    laps_count_2p = myfont.render(str(laps_formatted_2p), 1, TEXT)
    most_gui_2p = myfont.render('Most Laps:', 1, TEXT)
    most_count_2p = myfont.render(str(maxlaps_2p), 1, TEXT)
    time_gui_2p = myfont.render('This Run:', 1, TEXT)
    time_val_2p = myfont.render(str(timer_2p), 1, TEXT)
    fastest_gui_2p = myfont.render('Fastest:', 1, TEXT)
    fastest_val_2p = myfont.render(str(fast_str_2p), 1, TEXT)
    last_gui_2p = myfont.render('Last Lap:', 1, TEXT)
    last_val_2p = myfont.render(str(last_str_2p), 1, TEXT)
    speed_gui_2p = myfont.render('Speed:', 1, TEXT)
    speed_val_2p = myfont.render(str(speed_2p), 1, TEXT)

    if last_laptime_2p == 0:
        last_val_2p = myfont.render("--", 1, TEXT)
    if last_str_2p == 0:
        last_val_2p = myfont.render("--", 1, TEXT)
if joystick_yn == 2:
    if death_1p == 0 and death_2p == 0:
        screen.blit(rotatedSurf_1p, rotRect_1p)
        screen.blit(rotatedSurf_2p, rotRect_2p)

    if death_2p == 0:
        screen.blit(rotatedSurf_2p, rotRect_2p)

if death_1p == 0:
    screen.blit(rotatedSurf_1p, rotRect_1p)

if joystick_yn == 2:
    pygame.draw.rect(screen, PLAYER1, [0, 0, screen_width/2, border])
    pygame.draw.rect(screen, PLAYER2, [screen_width/2, 0, screen_width/2, border])
    screen.blit(most_gui_2p,   (20+6*((screen_width-20)/12),border/2))
    screen.blit(most_count_2p, (20+7.2*((screen_width-20)/12),border/2))
    screen.blit(laps_gui_2p,   (20+6*((screen_width-20)/12),10))
    screen.blit(laps_count_2p, (20+7.1*((screen_width-20)/12),10))
    screen.blit(last_gui_2p,   (20+8.1*((screen_width-20)/12), 10))
    screen.blit(last_val_2p,   (20+9.2*((screen_width-20)/12), 10))
    screen.blit(fastest_gui_2p, (20+8.1*((screen_width-20)/12), border/2))
    screen.blit(fastest_val_2p, (20+9.2*((screen_width-20)/12), border/2))
    screen.blit(time_gui_2p,   (20+10.1*((screen_width-20)/12), 10))
    screen.blit(time_val_2p,   (20+11.2*((screen_width-20)/12), 10))
    screen.blit(speed_gui_2p,  (20+10.1*((screen_width-20)/12),border/2))
    screen.blit(speed_val_2p,  (20+11.2*((screen_width-20)/12),border/2))

if joystick_yn == 2:
    screen.blit(laps_count_1p, (10+1.1*((screen_width-20)/12),10))

if joystick_yn < 2:
    pygame.draw.rect(screen, PLAYER1, [0, 0, screen_width/2, border])
    screen.blit(laps_count_1p, (10+1.2*((screen_width-20)/12),10))

screen.blit(laps_gui_1p,   (10,10))
screen.blit(most_gui_1p,   (10,border/2))
screen.blit(most_count_1p, (10+1.2*((screen_width-20)/12),border/2))
screen.blit(last_gui_1p,   (10+2.1*((screen_width-20)/12), 10))
screen.blit(last_val_1p,   (10+3.2*((screen_width-20)/12), 10))
screen.blit(fastest_gui_1p, (10+2.1*((screen_width-20)/12), border/2))
screen.blit(fastest_val_1p, (10+3.2*((screen_width-20)/12), border/2))
screen.blit(time_gui_1p,   (10+4.1*((screen_width-20)/12), 10))
screen.blit(time_val_1p,   (10+5.2*((screen_width-20)/12), 10))
screen.blit(speed_gui_1p,  (10+4.1*((screen_width-20)/12),border/2))
screen.blit(speed_val_1p,  (10+5.2*((screen_width-20)/12),border/2))
