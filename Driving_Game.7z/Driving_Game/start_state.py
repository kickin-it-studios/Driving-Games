import time

#Initialize Gamestate
death_1p = 0
degree_1p = 90

# Starting Position
xpos_1p = 200
ypos_1p = 200
previous_y_1p = 0

vel_x_1p = 0
vel_y_1p = 0

# Score
last_laptime_1p = 0
last_str_1p = 0
laps_1p = 0
time_val_1p = 0
penalty_1p = 0

fast_str_1p = "--"
fastestlap_1p = "--"

timer_1p = 0
maxlaps_1p = 0

# Inputs turned off to start
keys_1p=[False,False,False,False]

startTime_1p = 0
startTime_1p = time.time()
winlaptime_1p = time.time()


#Initialize Gamestate
death_2p = 0
degree_2p = 90

# Starting Position
xpos_2p = 200
ypos_2p = 200
previous_y_2p = 0

vel_x_2p = 0
vel_y_2p = 0

# Score
last_laptime_2p = 0.0
last_str_2p = 0.0
laps_2p = 0
time_val_2p = 0.0
penalty_2p = 0

fast_str_2p = "--"
fastestlap_2p = "--"

timer_2p = 0.0
maxlaps_2p = 0

# Inputs turned off to start
keys_2p=[False,False,False,False]

startTime_2p = 0
startTime_2p = time.time()
winlaptime_2p = time.time()

#######
# AI GOES HERE
#######

#Initialize Gamestate
death_ai = 0
degree_ai = 90

# Starting Position
# xpos_ai = 200
# ypos_ai = 200
xpos_ai = 400
ypos_ai = 175
previous_y_ai = 0

vel_x_ai = 0
vel_y_ai = 0

# Score
last_laptime_ai = 0
last_str_ai = 0
laps_ai = 0
time_val_ai = 0
penalty_ai = 0

fast_str_ai = "--"
fastestlap_ai = "--"

timer_ai = 0
maxlaps_ai = 0

longest_ai_run = 0

# Inputs turned off to start
keys_ai=[False,False,False,False]

startTime_ai = 0
startTime_ai = time.time()
winlaptime_ai = time.time()

oldCenter_ai = [xpos_ai, ypos_ai]
