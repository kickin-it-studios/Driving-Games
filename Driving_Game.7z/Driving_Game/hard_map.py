import random

#create a surface that will be seen by the user
screen_width =  1800
screen_height = 1000

#Track
border = 100
obst_x = [0,                0,                      0,                  screen_width-border,    screen_width/2-border]
obst_y = [0,                screen_height-border,   0,                  0,                      screen_height/2-border]
obst_w = [border,           screen_width,           screen_width,       border,                 2*border]
obst_h = [screen_height,    border,                 border,             screen_height,          2*border,]
# Track - Finish Line
finish = [0, screen_height/2-border, screen_width/2, 15]

for x in range(0,10):
    obst_x.append(random.randint(border*3,screen_width-border*4))
    obst_y.append(random.randint(border*3,screen_height-border*4))
    obst_w.append(random.randint(20,2*border))
    obst_h.append(random.randint(20,2*border))
