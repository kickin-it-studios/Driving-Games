Ok, shit is getting a bit out of control organizationally on my computer, and I also don't think I ever committed yesterday's code, so if anyone is trying to follow along later, i apologize for any confusion.

At this point I have a very nicely working 2 person multiplayer and single player free play racing game. I have also somewhat unsuccessfully implemented a "genetic algoritm" to the game!!! I made a very stripped down version called Genetic_drivingtrack.py that opens a csv file, does a round of evolution on it (reproduction, mutation, random additions), races it again, and then sorts the list from fastest to slowest.

I am very excited to see the code working, though I think i need to give the AI a better brain if I want it to actually be able to complete a full lap. I am also running into an issue of "spinners" popping up, where the car just stays alive as long as possible doing donuts. Rad? Yes. Successful strategy? maybe. What I was intending? definitely not.

The multiplayer can only currently run with 2 controllers plugged in. I'm working to improve that and the frame rate / other performance and organiational issues at some point...
