#
# 0 - XLINE = (border, screen_width+border)
# 1 - YLINE = (border, screen_height+border)
# 2 - TopOny = (-1,1)
# 3 - SideOnly = (-1,1)
# 4 - BothBorder = (-1,1)
# 5 - NeitherBorder = (-1,1)

import random
import csv
import time
import math
import glob
from operator import itemgetter

screen_width = 1000
border = 100
screen_height = 1000

newpop=[]

infile = sorted(glob.glob('*.csv'))

n_files = len(infile)-1

with open(infile[n_files], newline='') as f:
    reader = csv.reader(f)
    for row in reader:
        newpop.append(row)

print('1 '+str(len(newpop)))

# KILL BOTTOM PERFORMERS
newpop = newpop[:-75 or None]

print('2 '+str(len(newpop)))

# REPRODUCE TOP 25 PERFORMERS
for x in range (0,25):
    parent_picker = random.sample(range(24), k=2)
    parents = [newpop[parent_picker[0]], newpop[parent_picker[1]]]
    flip = [0,1]
    child = [parents[random.choice(flip)][0],parents[random.choice(flip)][1],parents[random.choice(flip)][2],parents[random.choice(flip)][3],parents[random.choice(flip)][4],parents[random.choice(flip)][5],0,0]
    newpop.append(child)

print('3 '+str(len(newpop)))

# MUTATE TOP 25 PERFORMERS
for x in range (0,25):
    original = newpop[x]
    mutated = [0,0,0,0,0,0,0,0]
    mutated[0] = int(original[0]) + random.randint(-20,20)
    mutated[1] = int(original[1]) + random.randint(-20,20)
    mutated[2] = float(original[2])*random.uniform(-2,2)
    mutated[3] = float(original[3])*random.uniform(-2,2)
    mutated[4] = float(original[4])*random.uniform(-2,2)
    mutated[5] = float(original[4])*random.uniform(-2,2)
    mutated[6] = 0
    mutated[7] = 0
    newpop.append(mutated)

print('4 '+str(len(newpop)))

for x in range (0,25):
    newpop.append([random.randint(0, (screen_width-2*border)/2),   random.randint(0, (screen_height-2*border)/2),   random.uniform(-1,1),   random.uniform(-1,1),   random.uniform(-1,1),   random.uniform(-1,1), 0, 0])

print('5 '+str(len(newpop)))

genetics = []


pop_size = 1000

for x in range(0,pop_size):
    genetics.append([random.randint(0, (screen_width-2*border)/2),   random.randint(0, (screen_height-2*border)/2),   random.uniform(-1,1),   random.uniform(-1,1),   random.uniform(-1,1),   random.uniform(-1,1), 0, 0])

for x in range (0,pop_size):
    genetics[x][6] = 0
    genetics[x][7] = 0

genetic_winners=sorted(genetics, key=itemgetter(7))

timestr = time.strftime("%Y%m%d-%H%M%S")

with open('output_'+timestr+'.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(genetic_winners)
