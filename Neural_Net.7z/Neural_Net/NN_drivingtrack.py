# Drift Racing - v2.0 (probably should be v35, but since tracking, this is v2)
# by Kyle Glackin with a hell of a lot of help from the Internet

import pygame
import math
from pygame.locals import *
import random
import time
import csv
import glob
from operator import itemgetter

# CONFIG FILES AND SETTINGS
# Change filename below (between /from/ and /import/) to switch files

# Configuration Files
from config_files.colorways.cool_color_scheme import *
from map import *
from base_car import *
import coord_wrapper

pygame.init()
screen = pygame.display.set_mode((screen_width,screen_height))

pygame.font.init()
myfont = pygame.font.SysFont('Bahnschrift', 24)

# Start State
from start_state import *

clock = pygame.time.Clock()

# Import Genes
oldpop=[]
infile = sorted(glob.glob('*.csv'))
n_file = len(infile)-1
with open(infile[n_file], 'r') as f:
    reader = csv.reader(f)
    oldpop = list(reader)

def unique_items(L):
    found = set()
    for item in L:
        if item[0] not in found:
            yield item
            found.add(item[0])

uniquepop = list(unique_items(oldpop))

spinkill = 0
for x in range (0, len(uniquepop)):
    if uniquepop[x][7] == '301' and uniquepop[x][6] == '0':
        spinkill += 1
# print(uniquepop[1])
# print(spinkill)
#
# print(len(oldpop))
# print(len(uniquepop))

newpop = []

for x in range (spinkill, 50+spinkill):
    newpop.append(uniquepop[x])

for x in range (0,len(newpop)):
        del newpop[x][6:8]

for x in range (0,100):
    parent_picker = random.sample(range(50), k=2)
    parents = [newpop[parent_picker[0]], newpop[parent_picker[1]]]
    flip = [0,1]
    child = [parents[random.choice(flip)][0],parents[random.choice(flip)][1],parents[random.choice(flip)][2],parents[random.choice(flip)][3],parents[random.choice(flip)][4],parents[random.choice(flip)][5]]
    newpop.append(child)

for x in range (0,150):
    original = newpop[x]
    mutated = [0,0,0,0,0,0]
    mutated[0] = int(original[0]) + random.randint(-50,50)
    mutated[1] = int(original[1]) + random.randint(-20,20)
    mutated[2] = float(original[2])*random.uniform(-1,2)
    mutated[3] = float(original[3])*random.uniform(-1,2)
    mutated[4] = float(original[4])*random.uniform(-1,2)
    mutated[5] = float(original[4])*random.uniform(-1,2)
    newpop.append(mutated)

for x in range (0,50):
    newpop.append([random.randint(0, (screen_width-2*border)/2),   random.randint(0, (screen_height-2*border)/2),   random.uniform(-1,1),   random.uniform(-1,1),   random.uniform(-1,1),   random.uniform(-1,1)])

var = -1
# Last Step
for x in range(0,len(newpop)):
    var += 1
    current_spec = newpop[x]
    alive = True

    spec_num = x
    spec_num_count = myfont.render(str(spec_num), 1, TEXT)

    if spec_num <= 50:
        type_ai = 'Parents'
    if 50 < spec_num <= 150:
        type_ai = 'Offspring'
    if 150 < spec_num <= 300:
        type_ai = 'Mutants'
    if spec_num > 300:
        type_ai = 'Random'


    #### MOVED FROM FIRST STEP OF RENDERER SO I COULD SEE TRAILS OF CARS #####
    screen.fill(BACKGROUND)


    from start_state import *

    timer_ai = 0

    xpos_chk = 0
    xpos_chk = 0
    axis_ai = 0

    while alive == True:

        vel_x_ai -= drag * vel_x_ai
        vel_y_ai -= drag * vel_y_ai

        # 0 - XLINE = (border, screen_width+border)
        # 1 - YLINE = (border, screen_height+border)
        # 2 - TopOny = (-1,1)
        # 3 - SideOnly = (-1,1)
        # 4 - Corner = (-1,1)
        # 5 - Interior = (-1,1)
        # 6 - Laps Completed
        # 7 - Timer

        if keys_ai[2] == False:
            keys_ai[2] = True
        if oldCenter_ai[0] < screen_width/2:                    # Left side
            if oldCenter_ai[1] < screen_height/2:               # Top half
                                                                    # Check what "sub-zone" we're in
                if oldCenter_ai[0] - int(current_spec[0]) >= border:        # further right than the buffer between car and left side wall
                    if oldCenter_ai[1] - int(current_spec[1]) <= border:        # higher up than the buffer between car and top wall
                        axis_ai = float(current_spec[2])                            # set axis to "top/bottom"
                    else:                                                       # otherwise assumed car is lower than the top buffer
                        axis_ai = float(current_spec[4])                            # set axis to "interior"
                if oldCenter_ai[0] - int(current_spec[0]) < border:         # further LEFT than buffer
                    if oldCenter_ai[1] - int(current_spec[1]) <= border:        # higher than the buffer between car and top wall
                        axis_ai = float(current_spec[3])                            # set axis to "corner"
                    if oldCenter_ai[1] - int(current_spec[1]) > border:         # assumed car is lower than buffer
                        axis_ai = float(current_spec[5])                            # set axis to "side"

        if oldCenter_ai[0] < screen_width/2:                    # Left side
            if oldCenter_ai[1] > screen_height/2:               # Bottom half
                                                                    # Check what "sub-zone" we're in
                if oldCenter_ai[0] - int(current_spec[0]) >= border:        # further right than left buffer
                    if oldCenter_ai[1] + int(current_spec[1]) >= border:        # lower than right buffer
                        axis_ai = float(current_spec[2])                            # set to "top/bottom"
                    else:                                                       # assumed left of left buffer
                        axis_ai = float(current_spec[4])                            # set to "interior"
                else:                                                       # assumed left of left buffer
                    if oldCenter_ai[1] - int(current_spec[1]) >= border:        # beyond bottom buffer
                        axis_ai = float(current_spec[3])                            # set axis to "corner"
                    else:
                        axis_ai = float(current_spec[5])

        if oldCenter_ai[0] > screen_width/2:                    # Right side
            if oldCenter_ai[1] < screen_height/2:                   # Top side
                # Check what "sub-zone" we're in
                if oldCenter_ai[0] + int(current_spec[0]) <= border:    # Left of border
                    if oldCenter_ai[1] - int(current_spec[1]) <= border:    # above top border
                        axis_ai = float(current_spec[2])                        #axis to "top"
                    else:
                        axis_ai = float(current_spec[4])
                else:
                    if oldCenter_ai[1] + int(current_spec[1]) <= border:
                        axis_ai = float(current_spec[3])
                    else:
                        axis_ai = float(current_spec[5])

        if oldCenter_ai[0] > screen_width/2:
            if oldCenter_ai[1] > screen_height/2:
                # Check what "sub-zone" we're in
                if oldCenter_ai[0] + int(current_spec[0]) <= border:
                    if oldCenter_ai[1] + int(current_spec[1]) >= border:
                        axis_ai = float(current_spec[2])
                    else:
                        axis_ai = float(current_spec[4])
                else:
                    if oldCenter_ai[1] - int(current_spec[1]) >= border:
                        axis_ai = float(current_spec[3])
                    else    :
                        axis_ai = float(current_spec[5])

        degree_ai = degree_ai - turningradius*(math.sqrt(vel_x_ai**2 + vel_y_ai**2))*(axis_ai/1.75)

        # Add the effect of the turn
        accel_x_ai = accel*math.sin(math.radians(degree_ai))
        accel_y_ai = accel*math.cos(math.radians(degree_ai))

        if keys_ai[2]==True:
            vel_x_ai += accel_x_ai
            vel_y_ai += accel_y_ai

        if keys_ai[3]==True:
            vel_x_ai -= accel_x_ai
            vel_y_ai -= accel_y_ai

        xpos_ai += vel_x_ai
        ypos_ai += vel_y_ai

        new_coords = coord_wrapper.coord_wrap(degree_ai, xpos_ai, ypos_ai, screen_width, screen_height, car_l)
        degree_ai = new_coords[0]
        xpos_ai = new_coords[1]
        ypos_ai = new_coords[2]

        car_ai =  pygame.Surface((car_w, car_l))
        car_ai.fill((FINISHLINE))
        #set a color key for blitting
        car_ai.set_colorkey((255, 0, 0))

        where_ai = xpos_ai, ypos_ai

        #draw surf to screen and catch the rect that blit returns
        blittedRect_ai = screen.blit(car_ai, where_ai)

        ##ROTATED
        #get center of surf for later
        oldCenter_ai = blittedRect_ai.center

        #rotate surf by DEGREE amount degrees
        rotatedSurf_ai =  pygame.transform.rotate(car_ai, degree_ai)

        #get the rect of the rotated surf and set it's center to the oldCenter
        rotRect_ai = rotatedSurf_ai.get_rect()
        rotRect_ai.center = oldCenter_ai

        speed_ai = (math.sqrt(vel_x_ai**2+vel_y_ai**2)*10)

        timer_ai += 1

        for x in range(0, len(obst_x)):
            if oldCenter_ai[0] > obst_x[x] and oldCenter_ai[0] < obst_x[x] + obst_w[x] and oldCenter_ai[1] > obst_y[x] and oldCenter_ai[1] < obst_y[x] + obst_h[x] and death_ai == 0:
                death_ai = 1
                grow_ai = 0
                winlaptime_ai = time.time()

        if previous_y_ai > finish[1]+finish[3] and oldCenter_ai[0] > finish[0] and oldCenter_ai[0] < finish[0]+finish[2] and  oldCenter_ai[1] <= finish[1]+finish[3]:
            if penalty_ai > 0:
                penalty_ai -= 1
                laps_ai += 1

            elif penalty_ai == 0:
                laps_ai += 1
                last_laptime_ai = time.time() - startTime_ai
                if fastestlap_ai == "--":
                    fastestlap_ai = last_laptime_ai
                if fastestlap_ai > last_laptime_ai:
                    fastestlap_ai = last_laptime_ai
                fast_str_ai = fastestlap_ai
                last_str_ai = last_laptime_ai

                startTime_ai = time.time()

            if laps_ai > maxlaps_ai:
                maxlaps_ai = laps_ai

        if previous_y_ai < finish[1]+finish[3] and oldCenter_ai[0] > finish[0] and oldCenter_ai[0] < finish[0]+finish[2] and oldCenter_ai[1] >= finish[1]+finish[3]:
            laps_ai -= 1
            penalty_ai += 1

        previous_y_ai = oldCenter_ai[1]

        #Check for movement
        if xpos_chk == xpos_ai and xpos_chk == ypos_ai:
            keys_ai[2] = False

        xpos_chk = xpos_ai
        ypos_chk = ypos_ai

    # RENDERING - - - - [|||] - - - - - - - -
    # RENDERING - - - - -[|||]- - - - - - - -
    # RENDERING - - - - - [|||] - - - - - - -
    # RENDERING - - - - - -[|||]- - - - - - -
    # RENDERING - - - - - - [|||] - - - - - -
    # RENDERING - - - - - - -[|||]- - - - - -
    # RENDERING - - - - - - - [|||] - - - - -
    # RENDERING - - - - - - - -[|||]- - - - -
        if death_ai > 0:
            newpop[var].append(maxlaps_ai)
            newpop[var].append(timer_ai)
            alive = False

        if timer_ai > 300:
            newpop[var].append(maxlaps_ai)
            newpop[var].append(timer_ai)
            alive = False

        pygame.draw.rect(screen, FINISHLINE, finish)

        # Draw the obstacle
        for x in range(0, len(obst_x)):
            pygame.draw.rect(screen, OBSTACLES, [obst_x[x], obst_y[x], obst_w[x], obst_h[x]])

        longest_ai_gui = myfont.render(str('Longest AI Run: '), 1, TEXT)
        longest_ai_val = myfont.render(str(timer_ai), 1, TEXT)
        most_gui_ai = myfont.render('Max AI Laps:', 1, TEXT)
        most_count_ai = myfont.render(str(maxlaps_ai), 1, TEXT)
        spec_num_gui = myfont.render('Species #:', 1, TEXT)
        type_label = myfont.render(str(type_ai), 1, TEXT)
        type_gui = myfont.render('Type:', 1, TEXT)

        if death_ai == 0:
                screen.blit(rotatedSurf_ai, rotRect_ai)

        screen.blit(longest_ai_gui,     (screen_width/2-215, 10+screen_height/2))
        screen.blit(longest_ai_val,     (screen_width/2-35, 10+screen_height/2))
        screen.blit(most_gui_ai,        (screen_width/2-215, -35+screen_height/2))
        screen.blit(most_count_ai,      (screen_width/2-35, -35+screen_height/2))
        screen.blit(spec_num_gui,       (screen_width/2+65, -35+screen_height/2))
        screen.blit(spec_num_count,     (screen_width/2+190, -35+screen_height/2))
        screen.blit(type_gui,           (screen_width/2+65, 10+screen_height/2))
        screen.blit(type_label,         (screen_width/2+160, 10+screen_height/2))
    # FINAL STEP OF GAME LOOP
        pygame.display.flip()

genetic_winners=sorted(newpop, key=itemgetter(7), reverse=True)
timestr = time.strftime("%Y%m%d-%H%M%S")
with open('output_'+timestr+'.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(genetic_winners)
