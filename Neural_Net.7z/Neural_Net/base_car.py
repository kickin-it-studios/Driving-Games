# Car
car_w = 10
car_l = 20

accel = .8
turningradius = 1.2
drag = .08
